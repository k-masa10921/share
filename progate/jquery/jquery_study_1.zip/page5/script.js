$(function() {
  // showメソッドを用いて、「#title」要素を表示してください
  $("#title").show();
  $("#image").fadeIn();
  // fadeInメソッドを用いて、「#image」要素を表示してください
  
  
});