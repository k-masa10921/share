$(function() {
  // 「#hide-text」要素に対するclickイベントを作成してください
  $("#hide-text").click(function(){
    $("#text").slideUp();
  });
  
});