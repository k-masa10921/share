$(function() {
  // 以下で、fadeOutメソッドを用いて<img>要素を隠してください
  $("img").fadeOut();
  
  // 以下で、slideUpメソッドを用いて<p>要素を隠してください
  $("p").slideUp();
  
});