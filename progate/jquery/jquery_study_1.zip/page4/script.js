$(function() {
  // slideUpメソッドを用いて、「#title」の要素を隠してください
  $("#title").slideUp();
  $(".lesson-item").fadeOut();
  // fadeOutメソッドを用いて、「.lesson-item」の要素を隠してください
  
  
});