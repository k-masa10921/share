// jQueryの型を用意してください
$(function(){
  
});
