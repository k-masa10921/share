$(function() {
  $('#login-show').click(function() {
    $('#login-modal').fadeIn();
  });
  
  // 「.signup-show」のclickイベントを作成してください
  $(".signup-show").click(function(){
    $("#signup-modal").fadeIn();
  });
  
});
