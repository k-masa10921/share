$(function() {
  // 「#login-show」要素に対するclickイベントを作成してください
  $("#login-show").click(function(){
    $("#login-modal").fadeIn();
  });
  
});