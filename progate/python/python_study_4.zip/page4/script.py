class MenuItem:
    pass


menu_item1 = MenuItem()

menu_item1.name = 'サンドイッチ'
print(menu_item1.name)

# menu_item1のpriceに「500」を代入してください
menu_item1.price = 500

# menu_item1のpriceを出力してください
print(menu_item1.price)
