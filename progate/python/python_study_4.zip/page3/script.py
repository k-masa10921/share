class MenuItem:
    pass


# MenuItemクラスのインスタンスを生成してください
menu_item1 = MenuItem()
