# MenuItemクラスを定義してください
class MenuItem:
    pass