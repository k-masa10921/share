class MenuItem:
    pass


menu_item1 = MenuItem()

menu_item1.name = 'サンドイッチ'
print(menu_item1.name)

menu_item1.price = 500
print(menu_item1.price)

# MenuItemクラスのインスタンスを生成してください
menu_item2 = MenuItem()

# menu_item2のnameに「チョコケーキ」を代入してください
menu_item2.name ="チョコケーキ"

# menu_item2のnameを出力してください
print(menu_item2.name)

# menu_item2のpriceに「400」を代入してください
menu_item2.price = 400

# menu_item2のpriceを出力してください
print (menu_item2.price) 
