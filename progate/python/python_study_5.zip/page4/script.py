from food import Food
from drink import Drink

food1 = Food('サンドイッチ', 500)

# food1のcalorieに「330」を代入してください
food1.calorie = 330

# food1に対してcalorie_infoメソッドを呼び出してください
food1.calorie_info()
