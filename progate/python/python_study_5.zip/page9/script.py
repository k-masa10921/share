from food import Food
from drink import Drink

food1 = Food('サンドイッチ', 500, 330)
print(food1.info())

# Drink()に引数を追加してください
drink1 = Drink('コーヒー', 300,180)

# 以下の1行は削除してください

print(drink1.info())
