from food import Food
from drink import Drink

food1 = Food('サンドイッチ', 500)
food1.calorie = 330

# food1に対してinfoメソッドを呼び出して戻り値を出力してください
print(food1.info())
