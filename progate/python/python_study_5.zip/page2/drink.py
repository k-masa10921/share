# fromとimportを用いて、MenuItemクラスを読み込んでください
from menu_item import MenuItem

# MenuItemクラスを継承して、Drinkクラスを定義してください
class Drink(MenuItem):
    pass
