# fromとimportを用いて、MenuItemクラスを読み込んでください
from menu_item import MenuItem

# MenuItemクラスを継承して、Foodクラスを定義してください
class Food(MenuItem):
    pass
