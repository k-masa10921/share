# apple_priceという変数に数値200を代入してください
apple_price = 200

# countという変数に数値5を代入してください
count = 5

# total_priceという変数に、apple_priceとcountを掛けたものを代入してください
total_price = apple_price * count 

# 「購入するりんごの個数は○○個です」となるように出力してください
print("購入するりんごの個数は"+str(count)+"個です")

# 「支払い金額は○○円です」となるように出力してくださ


print("支払い金額は"+str(total_price)+"円です")