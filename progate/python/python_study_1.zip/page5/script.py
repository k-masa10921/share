# 変数nameに文字列「にんじゃわんこ」を代入してください
name = "にんじゃわんこ"

# 変数nameの値を出力してください
print(name)

# 変数numberに数値の7を代入してください
number = 7

# 変数numberの値を出力してください
print(number)