money = 100
apple_price = 200

if money >= apple_price:
    print('りんごを買うことができます')
# if文の条件に当てはまらない場合に「お金が足りません」と出力してください
else:
    print("お金が足りません")
