age = 24
# ageを用いて「私は24歳です」と出力してください
print("私は"+str(age)+"歳です")

count = '5'
# countに1を足した値を出力してください
print(int(count)+1)