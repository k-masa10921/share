x = 10
# xが30より大きい場合に「xは30より大きいです」と出力してください
if x > 30 :
    print("xは30より大きいです")


money = 500
apple_price = 200
# moneyの値がapple_priceの値以上の時、「りんごを買うことができます」と出力してください
if money >= apple_price :
    print("りんごを買うことができます")
