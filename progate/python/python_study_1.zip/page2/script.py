# 「Hello World」と出力してください
print("Hello World")
