money = 2000
print(money)

# 変数moneyに5000を足して、変数moneyを上書きしてください
money += 5000

# 変数moneyの値を出力してください
print(money)