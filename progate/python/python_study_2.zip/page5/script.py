# 変数fruitsに辞書を代入してください
fruits={'apple':'りんご','banana':'バナナ'}

# 辞書fruitsのキー「banana」に対応する値を出力してください
print(fruits['banana'])

# 辞書fruitsを用いて、「appleは◯◯という意味です」となるように出力してください

print('appleは' + fruits['apple'] + 'という意味です')