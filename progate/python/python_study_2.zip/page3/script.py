fruits = ['apple', 'banana', 'orange']

# リストの末尾に文字列「grape」を追加してください
fruits.append("grape")

# 変数fruitsに代入したリストを出力してください
print(fruits)

# インデックス番号が0の要素を文字列「cherry」に更新してください
fruits[0]="cherry"

# インデックス番号が0の要素を出力してください
print(fruits[0])
