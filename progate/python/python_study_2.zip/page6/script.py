fruits = {'apple': 100, 'banana': 200, 'orange': 400}

# キー「banana」の値を数値「300」に更新してください
fruits['banana'] = 300

# キーが「grape」、値が数値の「500」の要素を辞書fruitsに追加してください
fruits['grape'] = 500

# fruitsの値を出力してください

print(fruits)