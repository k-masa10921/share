fruits = ['apple', 'banana', 'orange']

# for文を用いてリストの要素を1つずつ取り出し、「好きな果物は◯◯です」と出力してください
for fruit in fruits:
    print("好きな果物は"+fruit+"です")