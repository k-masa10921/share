# 引数を受け取れるようにしてください
def print_hand(hand):
    # 「◯◯を出しました」と出力されるように書き換えてください
    print(hand+'を出しました')

# 引数に文字列グーを入れてください
print_hand("グー")

# 引数を文字列パーとして関数print_handを呼び出してください
print_hand("パー")
