# 関数print_handを定義してください
def print_hand():
    print("グーを出しました")

# 関数print_handを呼び出してください
print_hand()
  