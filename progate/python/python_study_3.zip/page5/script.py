# 仮引数nameの初期値を設定してください
def print_hand(hand, name="ゲスト"):
    print(name + 'は' + hand + 'を出しました')

# 引数に文字列グーのみを入れてください
print_hand("グー")